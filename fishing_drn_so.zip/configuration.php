<?php


class Configuration
{
    public static function token()
    {
        return "7004257245:AAEjQ_5lSh13NqNEBR01m3oB-nYko5wcVVo";
    }
    public static function admin ()
    {
        return 348759045;
    } 
    public static function admins ()
    {
        return [
            self::admin(),
            1831369371,
        ];
    }
}